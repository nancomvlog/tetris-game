import pygame
import random
import asyncio  # 必须导入用于网页兼容

# --- 配置 ---
BLOCK_SIZE = 30
BOARD_WIDTH = 10
BOARD_HEIGHT = 20
SIDEBAR_WIDTH = 160
SCREEN_WIDTH = BOARD_WIDTH * BLOCK_SIZE + SIDEBAR_WIDTH
SCREEN_HEIGHT = BOARD_HEIGHT * BLOCK_SIZE

BLACK = (10, 10, 15)
WHITE = (220, 220, 220)
GRAY = (50, 50, 60)
COLORS = [
    (0, 200, 200), (200, 200, 0), (160, 0, 160),
    (0, 160, 0), (200, 0, 0), (0, 0, 180), (200, 120, 0)
]

SHAPES = [
    [[1, 1, 1, 1]], [[1, 1], [1, 1]], [[0, 1, 0], [1, 1, 1]],
    [[0, 1, 1], [1, 1, 0]], [[1, 1, 0], [0, 1, 1]],
    [[1, 0, 0], [1, 1, 1]], [[0, 0, 1], [1, 1, 1]]
]


class Tetris:
    def __init__(self):
        pygame.init()
        pygame.key.set_repeat(160, 50)
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("TETRIS RETRO WASM")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont(None, 36)
        self.small_font = pygame.font.SysFont(None, 24)
        self.reset_game()

    def reset_game(self):
        self.grid = [[None for _ in range(BOARD_WIDTH)] for _ in range(BOARD_HEIGHT)]
        self.score = 0
        self.game_over = False
        self.next_shape = random.choice(SHAPES)
        self.next_color = random.choice(COLORS)
        self.new_piece()

    def new_piece(self):
        self.current_shape = self.next_shape
        self.current_color = self.next_color
        self.next_shape = random.choice(SHAPES)
        self.next_color = random.choice(COLORS)
        self.piece_x = BOARD_WIDTH // 2 - len(self.current_shape[0]) // 2
        self.piece_y = 0
        if self.check_collision(self.piece_x, self.piece_y):
            self.game_over = True

    def draw_3d_block(self, x, y, color):
        rect = (x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE)
        pygame.draw.rect(self.screen, color, rect)
        h = [min(c + 75, 255) for c in color]
        s = [max(c - 75, 0) for c in color]
        pygame.draw.line(self.screen, h, (rect[0], rect[1]), (rect[0] + BLOCK_SIZE - 1, rect[1]), 2)
        pygame.draw.line(self.screen, h, (rect[0], rect[1]), (rect[0], rect[1] + BLOCK_SIZE - 1), 2)
        pygame.draw.line(self.screen, s, (rect[0], rect[1] + BLOCK_SIZE - 1),
                         (rect[0] + BLOCK_SIZE - 1, rect[1] + BLOCK_SIZE - 1), 2)
        pygame.draw.line(self.screen, s, (rect[0] + BLOCK_SIZE - 1, rect[1]),
                         (rect[0] + BLOCK_SIZE - 1, rect[1] + BLOCK_SIZE - 1), 2)

    def check_collision(self, x, y, shape=None):
        shape = shape or self.current_shape
        for r, row in enumerate(shape):
            for c, val in enumerate(row):
                if val:
                    if (x + c < 0 or x + c >= BOARD_WIDTH or
                            y + r >= BOARD_HEIGHT or
                            self.grid[y + r][x + c] is not None):
                        return True
        return False

    def clear_lines(self):
        lines_to_clear = [i for i, row in enumerate(self.grid) if all(cell is not None for cell in row)]
        if lines_to_clear:
            for _ in range(2):
                for row_idx in lines_to_clear:
                    pygame.draw.rect(self.screen, WHITE,
                                     (0, row_idx * BLOCK_SIZE, BOARD_WIDTH * BLOCK_SIZE, BLOCK_SIZE))
                pygame.display.flip()
                pygame.time.delay(40)
            new_grid = [row for i, row in enumerate(self.grid) if i not in lines_to_clear]
            for _ in range(len(lines_to_clear)):
                new_grid.insert(0, [None for _ in range(BOARD_WIDTH)])
            self.grid = new_grid
            self.score += (len(lines_to_clear) ** 2) * 100

    def draw_ui(self):
        pygame.draw.rect(self.screen, (20, 20, 30), (BOARD_WIDTH * BLOCK_SIZE, 0, SIDEBAR_WIDTH, SCREEN_HEIGHT))
        pygame.draw.line(self.screen, GRAY, (BOARD_WIDTH * BLOCK_SIZE, 0), (BOARD_WIDTH * BLOCK_SIZE, SCREEN_HEIGHT), 2)
        self.screen.blit(self.font.render("SCORE", True, WHITE), (BOARD_WIDTH * BLOCK_SIZE + 20, 40))
        self.screen.blit(self.font.render(str(self.score), True, (0, 255, 120)), (BOARD_WIDTH * BLOCK_SIZE + 20, 75))
        self.screen.blit(self.font.render("NEXT", True, WHITE), (BOARD_WIDTH * BLOCK_SIZE + 20, 180))
        for r, row in enumerate(self.next_shape):
            for c, val in enumerate(row):
                if val: self.draw_3d_block(BOARD_WIDTH + 1.5 + c, 8 + r, self.next_color)

    async def show_game_over(self):
        waiting = True
        blink_timer = 0
        while waiting:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay.set_alpha(5)
            overlay.fill((0, 0, 0))
            self.screen.blit(overlay, (0, 0))

            msg = self.font.render("GAME OVER", True, (255, 50, 50))
            self.screen.blit(msg, (SCREEN_WIDTH // 2 - msg.get_width() // 2, SCREEN_HEIGHT // 2 - 60))

            blink_timer += 1
            if (blink_timer // 30) % 2 == 0:
                hint = self.small_font.render("PRESS 'R' TO RESTART", True, (180, 180, 180))
                self.screen.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT // 2 + 50))

            pygame.display.flip()
            await asyncio.sleep(0)  # 网页异步核心

            for event in pygame.event.get():
                if event.type == pygame.QUIT: return "QUIT"
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.reset_game()
                        return "RESTART"
                    if event.key == pygame.K_ESCAPE: return "QUIT"
        return "QUIT"

    async def run(self):
        fall_time = 0
        while not self.game_over:
            self.screen.fill(BLACK)
            fall_speed = max(100, 500 - (self.score // 1000) * 50)
            fall_time += self.clock.get_rawtime()
            self.clock.tick()

            for event in pygame.event.get():
                if event.type == pygame.QUIT: return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT and not self.check_collision(self.piece_x - 1, self.piece_y):
                        self.piece_x -= 1
                    if event.key == pygame.K_RIGHT and not self.check_collision(self.piece_x + 1, self.piece_y):
                        self.piece_x += 1
                    if event.key == pygame.K_DOWN and not self.check_collision(self.piece_x, self.piece_y + 1):
                        self.piece_y += 1
                    if event.key == pygame.K_SPACE:
                        new_s = [list(row) for row in zip(*self.current_shape[::-1])]
                        if not self.check_collision(self.piece_x, self.piece_y, new_s):
                            self.current_shape = new_s

            if fall_time > fall_speed:
                if not self.check_collision(self.piece_x, self.piece_y + 1):
                    self.piece_y += 1
                else:
                    for r, row in enumerate(self.current_shape):
                        for c, val in enumerate(row):
                            if val: self.grid[self.piece_y + r][self.piece_x + c] = self.current_color
                    self.clear_lines()
                    self.new_piece()
                fall_time = 0

            for r, row in enumerate(self.grid):
                for c, color in enumerate(row):
                    if color: self.draw_3d_block(c, r, color)
            for r, row in enumerate(self.current_shape):
                for c, val in enumerate(row):
                    if val: self.draw_3d_block(self.piece_x + c, self.piece_y + r, self.current_color)

            self.draw_ui()
            pygame.display.flip()
            await asyncio.sleep(0)  # 网页异步核心

        # 处理游戏结束
        res = await self.show_game_over()
        if res == "RESTART":
            await self.run()


async def main():
    game = Tetris()
    await game.run()


if __name__ == "__main__":
    asyncio.run(main())